import { getUncachableStripeClient } from "./stripeClient";

async function createProducts() {
  try {
    const stripe = await getUncachableStripeClient();
    console.log("Creating CourierDF products and prices in Stripe...");

    const existingProducts = await stripe.products.list({ limit: 100, active: true });
    const existingNames = new Set(existingProducts.data.map(p => p.name));

    if (!existingNames.has("Standard Job Post")) {
      const jobPost = await stripe.products.create({
        name: "Standard Job Post",
        description: "Post a single job listing on CourierDF",
        metadata: { type: "job_post" },
      });
      await stripe.prices.create({
        product: jobPost.id,
        unit_amount: 4900,
        currency: "usd",
        metadata: { type: "job_post" },
      });
      console.log(`Created: Standard Job Post ($49.00)`);
    } else {
      console.log("Standard Job Post already exists, skipping.");
    }

    if (!existingNames.has("Featured Job Upgrade")) {
      const featuredUpgrade = await stripe.products.create({
        name: "Featured Job Upgrade",
        description: "Upgrade a job listing to featured status for 30 days",
        metadata: { type: "featured_job" },
      });
      await stripe.prices.create({
        product: featuredUpgrade.id,
        unit_amount: 2900,
        currency: "usd",
        metadata: { type: "featured_job" },
      });
      console.log(`Created: Featured Job Upgrade ($29.00)`);
    } else {
      console.log("Featured Job Upgrade already exists, skipping.");
    }

    if (!existingNames.has("Company Premium Plan")) {
      const companyPremium = await stripe.products.create({
        name: "Company Premium Plan",
        description: "Premium subscription for courier companies — featured badge, unlimited job posts, priority support",
        metadata: { type: "company_premium" },
      });
      await stripe.prices.create({
        product: companyPremium.id,
        unit_amount: 9900,
        currency: "usd",
        recurring: { interval: "month" },
        metadata: { type: "company_premium_monthly" },
      });
      await stripe.prices.create({
        product: companyPremium.id,
        unit_amount: 99900,
        currency: "usd",
        recurring: { interval: "year" },
        metadata: { type: "company_premium_yearly" },
      });
      console.log(`Created: Company Premium Plan ($99/mo, $999/yr)`);
    } else {
      console.log("Company Premium Plan already exists, skipping.");
    }

    if (!existingNames.has("Driver Premium Plan")) {
      const driverPremium = await stripe.products.create({
        name: "Driver Premium Plan",
        description: "Premium subscription for drivers — featured visibility, priority in search, job alerts",
        metadata: { type: "driver_premium" },
      });
      await stripe.prices.create({
        product: driverPremium.id,
        unit_amount: 2900,
        currency: "usd",
        recurring: { interval: "month" },
        metadata: { type: "driver_premium_monthly" },
      });
      await stripe.prices.create({
        product: driverPremium.id,
        unit_amount: 29000,
        currency: "usd",
        recurring: { interval: "year" },
        metadata: { type: "driver_premium_yearly" },
      });
      console.log(`Created: Driver Premium Plan ($29/mo, $290/yr)`);
    } else {
      console.log("Driver Premium Plan already exists, skipping.");
    }

    console.log("\n✓ All products created successfully!");
    console.log("Webhooks will sync this data to your database automatically.");
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : String(error);
    console.error("Error creating products:", message);
    process.exit(1);
  }
}

createProducts();
