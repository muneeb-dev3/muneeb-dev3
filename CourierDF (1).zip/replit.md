# CourierDF — Logistics Marketplace Platform

## Overview

CourierDF is a multi-role logistics marketplace platform facilitating interactions between drivers, courier companies, and shippers. The platform aims to streamline logistics operations by providing a centralized hub for job postings, driver recruitment, and shipment requests. Key capabilities include user authentication, role-based access control, comprehensive profile management for drivers and companies, job listing and application functionalities, and administrative tools for platform moderation and management. The project's vision is to become a leading marketplace connecting logistics providers with demand, optimizing efficiency and expanding market opportunities for all participants.

## User Preferences

I want iterative development and detailed explanations. Ask before making major changes.

## System Architecture

CourierDF is built as a pnpm workspace monorepo using TypeScript, ensuring a structured and scalable development environment.

**Technology Stack:**
- **Monorepo & Build:** pnpm workspaces, Node.js 24, TypeScript 5.9, esbuild (CJS bundle for API server), Vite (frontend).
- **Frontend:** React, Vite, Tailwind CSS, shadcn/ui for UI components, and wouter for client-side routing.
- **Backend:** Express 5 for the API server.
- **Database:** PostgreSQL with Drizzle ORM.
- **Authentication:** Replit Auth (OpenID Connect with PKCE).
- **Validation:** Zod (`zod/v4`) and `drizzle-zod`.
- **API Codegen:** Orval, generating client code from an OpenAPI specification.

**Core Features & Design Patterns:**

- **User Roles:** Supports Driver, Company, Admin, and future Shipper roles, each with specific functionalities and access levels.
- **RBAC (Role-Based Access Control):** Implemented server-side using middleware (`requireAuth`, `requireRole`) to enforce permissions based on user roles and account status (`active`/`suspended`).
- **Data Taxonomy:** Comprehensive reference data management for certifications, capabilities, industries, vehicle types, and cities to standardize listings and profiles.
- **Profile Management:** Detailed profiles for drivers (vehicles, certifications, capabilities, industries) and companies (services, service areas, capabilities, industries, fleet).
- **Job Management:** Companies can create, manage, and track job postings. Drivers can apply to jobs and manage applications.
- **SEO Optimization:** Dynamic sitemap generation and SEO-friendly landing pages for cities, industries, and capabilities to enhance discoverability.
- **Object Storage:** Integrated secure object storage for handling file uploads (e.g., driver documents, company logos) with presigned URLs.
- **Billing & Subscriptions:** Integration with Stripe for managing products, prices, subscriptions, and payments, synchronized via `stripe-replit-sync`.
- **Admin Panel:** A dedicated administration interface for user, driver, company, and job moderation, taxonomy management, and audit logging.
- **Onboarding Wizards:** Guided onboarding processes for new drivers and companies to facilitate initial setup.
- **Monorepo Structure:** Organizes the project into distinct packages for `api-server`, `courier-df` (frontend), shared libraries (`api-spec`, `api-client-react`, `api-zod`, `db`, `object-storage-web`, `replit-auth-web`), and `scripts`.

## External Dependencies

- **Replit Auth:** Used for OpenID Connect (OIDC) based user authentication with PKCE.
- **PostgreSQL:** Primary database for all application data, managed via Drizzle ORM.
- **Stripe:** Integrated for handling all billing, subscription management, payment processing, and customer portal functionalities.
- **Orval:** API client code generation tool from OpenAPI specifications.
- **Tailwind CSS:** Utility-first CSS framework for frontend styling.
- **shadcn/ui:** UI component library for React.
- **Vite:** Frontend build tool and development server.
- **Express:** Web application framework for the Node.js backend.
- **Zod:** Schema declaration and validation library.
- **Nodemailer:** Email transport library for sending job alert notifications.

## Job Alert Notifications

The platform supports driver job alert notifications with three frequency modes:
- **Instant:** Triggers immediately when an admin approves a new job matching alert criteria.
- **Daily:** Batched delivery every hour (checks if 24h since last send), sends matching jobs from the past day.
- **Weekly:** Batched delivery every 6 hours (checks if 7 days since last send), sends matching jobs from the past week.

Alert matching criteria include: jobType, city, state, industry, routeType, and keyword search in job titles. When SMTP is not configured (no `SMTP_HOST`/`SMTP_USER`/`SMTP_PASS` env vars), emails are logged to console for development. Configure SMTP for production email delivery. The `EMAIL_FROM` env var sets the sender address (default: `noreply@courierdf.com`).

Key files: `notificationService.ts` (matching + sending), `alertScheduler.ts` (interval timers), admin route `POST /admin/alerts/process` (manual trigger).